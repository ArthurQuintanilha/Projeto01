import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'io.ionic.starter',
  appName: 'GerenciarTarefas20212016833',
  webDir: 'www',
  bundledWebRuntime: false
};

export default config;
